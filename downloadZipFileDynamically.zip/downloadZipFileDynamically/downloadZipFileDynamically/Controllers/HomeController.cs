﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using downloadZipFileDynamically.Models;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using Microsoft.AspNetCore.Hosting;

namespace downloadZipFileDynamically.Controllers
{
    public class HomeController : Controller
    {
        private readonly MyAppContext _context;
        private readonly IHostingEnvironment _hostEnvironment;
        private readonly IWebHostEnvironment WebHostEnvironment;
        public HomeController(MyAppContext context, IHostingEnvironment hostEnvironment, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _hostEnvironment = hostEnvironment;
            WebHostEnvironment = webHostEnvironment;
        }
        public IActionResult Index()
        {
            var data = _context.MyDataStoreClass.ToList();
            return View(data);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(MyDataStoreClass Viewmodel)
        {
            string filename = UploadFile(Viewmodel);
            var data = new MyDataStoreClass()
            {
                FileName = filename,
            };
            await _context.MyDataStoreClass.AddAsync(data);
            await _context.SaveChangesAsync();
            return View();
        }
        private string UploadFile(MyDataStoreClass vm)
        {
            string fileName = null;
            if (vm.File != null)
            {
                string uploadDir = Path.Combine(WebHostEnvironment.WebRootPath, "MyAllFiles");
                fileName = Guid.NewGuid().ToString() + "-" + vm.File.FileName;
                string filePath = Path.Combine(uploadDir, fileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    vm.File.CopyTo(fileStream);
                }
            }
            return fileName;
        }


        public FileResult Download(int id)
        {
            var webRoot = _hostEnvironment.WebRootPath;
            var attachments = _context.MyDataStoreClass.FirstOrDefault(x=>x.Id == id);
            var filename =  "DownloadFile" + ".zip";
            var tempOutput = webRoot + "/MyAllFiles/" + filename;

            using (ZipOutputStream ozipOutputStream = new ZipOutputStream(System.IO.File.Create(tempOutput)))
            {
                ozipOutputStream.SetLevel(9);
                byte[] buffer = new byte[50000];
                var Imagelist = new List<string>();

                Imagelist.Add(webRoot + "/MyAllFiles/" + attachments.FileName);

                for (int i = 0; i < Imagelist.Count; i++)
                {
                    ZipEntry entry = new ZipEntry(Path.GetFileName(Imagelist[i]));
                    entry.DateTime = DateTime.Now;
                    entry.IsUnicodeText = true;
                    ozipOutputStream.PutNextEntry(entry);

                    using (FileStream ofileStream = System.IO.File.OpenRead(Imagelist[i]))
                    {
                        int sourceBytes;
                        do
                        {
                            sourceBytes = ofileStream.Read(buffer, 0, buffer.Length);
                            ozipOutputStream.Write(buffer, 0, sourceBytes);
                        } while (sourceBytes > 0);
                    }
                }

                ozipOutputStream.Finish();
                ozipOutputStream.Flush();
                ozipOutputStream.Close();
            }

            byte[] finalResult = System.IO.File.ReadAllBytes(tempOutput);
            if (System.IO.File.Exists(tempOutput))
            {
                System.IO.File.Delete(tempOutput);
            }

            //if (finalResult != null || finalResult.Any())
            //{
            //    throw new Exception(String.Format("Nothing Found"));
            //}
            return File(finalResult, "application/zip", filename);
        }
    }
}
